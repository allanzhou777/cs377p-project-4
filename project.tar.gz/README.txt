This is an assignment for my cs77p performance programming class that runs the page rank algorithm. 

To run the code, run the following
`make clean`
`make wiki` or `make rmat15` or `make road-NY`